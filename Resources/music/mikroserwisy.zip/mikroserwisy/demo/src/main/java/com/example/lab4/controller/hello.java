package com.example.lab4.controller;

import com.example.lab4.dao.Person;
import com.example.lab4.repository.PersonsRepository;
import com.example.lab4.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
public class hello {

    @Bean
    public CommandLineRunner demo(PersonsRepository repository) {
        return args -> {
            // save a few customers
            repository.save(new Person("John", "Doe", "IT"));
            repository.save(new Person("John", "Smith", "tester"));

            // fetch all customers
            //log.info("Customers found with findAll():");
            //log.info("-------------------------------");

            repository.findAll().forEach(person -> System.out.println(person.toString()));
        };

    }


    @Autowired
    private PersonService personService;

    @GetMapping("/persons")
    public List<Person> getPersons() {
        return personService.getPersons();
    }

    @GetMapping("/person/{id}")
    public Person getPerson(@PathVariable long id) {
        return personService.getPerson(id);
    }

    @PostMapping("/create")
    public Person createPerson(@RequestBody Person person) {
        return personService.create(person);
    }

    @GetMapping("/hello")
    public ResponseEntity<recordPreson> write(@RequestParam(value = "name", defaultValue = "świecie") String name) {
    URI location = URI.create("http://localhost:8080/hello");

    recordPreson recordPerson = new recordPreson("Cześć " + name);

    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(location);
    headers.setContentType(MediaType.APPLICATION_JSON);

    return new ResponseEntity<>(recordPerson,headers, HttpStatus.OK);
    
    }

}
