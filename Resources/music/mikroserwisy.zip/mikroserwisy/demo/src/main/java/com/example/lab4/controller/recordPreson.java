package com.example.lab4.controller;

public record recordPreson(String name) {

}
