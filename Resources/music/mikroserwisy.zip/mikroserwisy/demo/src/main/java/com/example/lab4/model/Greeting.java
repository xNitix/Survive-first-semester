package com.example.lab4.model;

public record Greeting() {
}
