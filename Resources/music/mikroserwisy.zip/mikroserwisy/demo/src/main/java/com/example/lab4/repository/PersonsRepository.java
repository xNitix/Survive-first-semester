package com.example.lab4.repository;
import com.example.lab4.dao.Person;
import org.springframework.data.repository.CrudRepository;

public interface PersonsRepository extends CrudRepository<Person, Long> {

}
