package com.example.lab4.service;
import com.example.lab4.dao.Person;
import com.example.lab4.repository.PersonsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonsRepository personsRepository;

    @Override
    public List<Person> getPersons() {
        return (List<Person>) personsRepository.findAll();
    }

    @Override
    public Person getPerson(String surname) {
        return null;
    }

    @Override
    public Person create(Person person) {
        return personsRepository.save(person);
    }

    @Override
    public Person getPerson(long id) {
        return personsRepository.findById(id).orElse(null);
    }


}