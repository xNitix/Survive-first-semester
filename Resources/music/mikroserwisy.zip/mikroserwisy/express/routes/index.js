// index.js

var express = require('express');
var router = express.Router();

// GET /
router.get('/', (req, res, next) => {
    res.status(200).json({ message: 'Hello, this is the root path!' });
});

// POST /
router.post('/', (req, res, next) => {
    // Handle POST request logic here
    res.status(200).json({ message: 'POST request successful!' });
});

module.exports = router;