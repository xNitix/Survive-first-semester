const express = require('express');
const router = express.Router();
const { PersonSchema } = require('../db');

// GET all persons
router.get('/', async (req, res, next) => {
    try {
        const persons = await PersonSchema.findAll();
        res.json(persons);
    } catch (error) {
        next(error);
    }
});

// GET person by ID
router.get('/:id', async (req, res, next) => {
    const id = req.params.id;
    try {
        const person = await PersonSchema.findByPk(id);
        res.json(person);
    } catch (error) {
        next(error);
    }
});

// POST create new person
router.post('/', async (req, res, next) => {
    const { name, surname, job } = req.body;
    try {
        const newPerson = await PersonSchema.create({ name, surname, job });
        res.json(newPerson);
    } catch (error) {
        next(error);
    }
});

// DELETE person by ID
router.delete('/:id', async (req, res, next) => {
    const id = req.params.id;
    try {
        const result = await PersonSchema.destroy({
            where: { id: id }
        });

        if (result === 1) {
            res.json({ message: 'Osoba usunięta pomyślnie.' });
        } else {
            res.status(404).json({ message: 'Osoba o podanym identyfikatorze nie została znaleziona.' });
        }
    } catch (error) {
        next(error);
    }
});

// DELETE all persons
router.delete('/', async (req, res, next) => {
    try {
        await PersonSchema.destroy({
            where: {},
            truncate: true
        });

        await sequelize.query('DELETE FROM sqlite_sequence WHERE name="Persons"');
        await sequelize.query('INSERT INTO sqlite_sequence (name, seq) VALUES ("Persons", 0)');

        res.json({ message: 'Wszystkie osoby usunięte pomyślnie.' });
    } catch (error) {
        next(error);
    }
});

module.exports = router;