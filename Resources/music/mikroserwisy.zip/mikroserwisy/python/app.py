from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from sqlalchemy import Column, Integer, String
from marshmallow import fields, Schema, post_load

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///demo.sqlite"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)

#po aqlalchemy
ma = Marshmallow(app)

class Person(db.Model):
    id = Column(Integer, primary_key=True)
    name = Column(String)
    surname = Column(String)
    job = Column(String)

    @post_load
    def make_user(self, data, **kwargs):
        return Person(**data)

class PersonSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Person

@app.route('/', methods=['GET'])
def index():
    return jsonify({"message": "Hello, World!"})

@app.route('/<nazwa>', methods=['GET'])
def some_func(nazwa):
    nazwa_param = nazwa

    return jsonify({
        "message": f"witaj {nazwa_param}" 
    })

@app.route('/persons', methods=['GET', 'POST'])
def manage_persons():
    if request.method == 'GET':
        all_persons = Person.query.all()

        person_schema = PersonSchema(many=True)
        serialized_persons = person_schema.dump(all_persons)

        return jsonify({"persons": serialized_persons})
    elif request.method == 'POST':
        data = request.json
        new_person = Person(name=data['name'], surname=data['surname'], job=data['job'])

        db.session.add(new_person)
        db.session.commit()

        return jsonify({"message": "Person added"})


@app.route('/persons/<int:person_id>', methods=['GET']) 
def get_person_by_id(person_id):
    person = Person.query.get_or_404(person_id)

    #Marshmallow, serializacja danych
    person_schema = PersonSchema()
    serialized_person = person_schema.dump(person)

    return jsonify({"person": serialized_person})

@app.route('/persons/<int:person_id>', methods=['DELETE'])
def delete_person(person_id):
    person = Person.query.get_or_404(person_id)

    db.session.delete(person)
    db.session.commit()

    return jsonify({"message": "Person deleted"})


with app.app_context():
    db.drop_all()
    db.create_all()

    person = Person(name="ser", surname="serowy", job='it')

    db.session.add(person)
    db.session.commit()

    all_persons = db.session.execute(db.select(Person)).scalars()

    person_by_id = Person.query.get_or_404(1)

    #Marshmallow, serializacja
    person_schema = PersonSchema()
    serialized_person = person_schema.dump(person) 
    serialized_persons = PersonSchema(many=True).dump(all_persons) 
    json_data = {"name": "John", "surname": "Doe", "job": "developer"}
    deserialized_person = person_schema.load(json_data)

if __name__ == '__main__':
    app.run(debug=True)